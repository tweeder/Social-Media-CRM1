﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApplication4
{
    internal class Twitter {
       public static  WebBrowser webBrowser3 = null;
         int firstclickbyattribute =0;
        
       public Twitter(WebBrowser webBrowser2)
        { webBrowser3 = webBrowser2;
            webBrowser3.DocumentCompleted += webBrowser3_DocumentCompleted;//this has to be decleredin the sam merhod as itweb3 is isnatained
            // System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss" + webBrowser3.Document.Title);
             System.Diagnostics.Debug.WriteLine("2222222222222222222222" );
        }

        public  Twitter() { }



   // { //SqlCeConnection thisConnection

       public void twitter1()
    {
            // Form1.textBox1.Text = "Picture to post";

            System.Diagnostics.Debug.WriteLine("insied  Yelper class way to  go little buddy2");
             webBrowser3.Navigate("https://twitter.com/?lang=en");

            // webBrowser3.Navigate("https://twitter.com/?lang=en");
            System.Diagnostics.Debug.WriteLine("insiedaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  Yelper class way to  go little buddy2");



        }

 private void webBrowser3_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
          {    if (firstclickbyattribute < 1)
              {
                  System.Diagnostics.Debug.WriteLine("insied  aaaaaaaaaaaYelper class way to  go little buddydoc completed");

                  firstclickbyattribute++;
               //   clickThroughByTags(2y);
              }

          } 
        public void clickThroughByTags(int s)
        {
            /////////
           // System.Diagnostics.Debug.WriteLine("u made it here hehehaaaaaaaaaeh");
          //  System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss" + webBrowser3.Document.Title);
            HtmlElementCollection links1 =  webBrowser3.Document.GetElementsByTagName("a");
           // string e = links1.ToString();
            //System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss"+e);

            // HtmlElementCollection lnks1 = webBrowser1.Focus(d);
            /////////////
            ////////////
            foreach (HtmlElement link in links1)
            {
                System.Diagnostics.Debug.WriteLine("linklinklink" + link.ToString());//99
                if (firstclickbyattribute <= s)
                {
                    link.GetAttribute("href");//99

                    link.InvokeMember("Click");//99
                    System.Diagnostics.Debug.WriteLine("linklddddddddinklink" + link);//99 if only 99 line where in this it would perpetualy open links
                    firstclickbyattribute++;

                }

            } //try a switch case style whne efactoring


        }
          

    }
}














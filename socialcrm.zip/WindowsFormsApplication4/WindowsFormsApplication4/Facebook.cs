﻿namespace WindowsFormsApplication4
{
    class Facebook
    {
        public void gigi()
        {
            System.Diagnostics.Debug.WriteLine("insied facebook instance");
        }

    }
   
}

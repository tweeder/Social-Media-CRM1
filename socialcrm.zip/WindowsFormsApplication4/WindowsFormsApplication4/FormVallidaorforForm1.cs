﻿using System.Windows.Forms;
using WindowsFormsApplication4;
namespace WindowsFormsApplication4
{           // the media site to up date is passed in by butt4 in form1 being clicked
    internal class FormVallidaorforForm1
        //
    { public FormVallidaorforForm1(int q, WebBrowser webBrowser22) {
            bool valid = false ;

            //System.Diagnostics.Debug.WriteLine("insied validator");
            if (valid == true) { }
            else
            { ///make ito a switch statment when possale to make it easier to read

                if (q==0) {
                    // q = "FaceBook";
                    Facebook facebookinstance = new Facebook();
                    facebookinstance.gigi();
                }
               
                else if (q == 1)
                    {
                 //   q = "yelp";
                }
                else if (q == 2)
                {
                    Twitter twiter12 = new Twitter(webBrowser22);

                    System.Diagnostics.Debug.WriteLine("Twiter selected in formValidator" + q);
                    //starts a classs to sign up with yelp
                    twiter12.twitter1();
                 //   q = "Yelp";
                }


                System.Diagnostics.Debug.WriteLine("insied validator and ur form needs fixin"+q);
            }


        }

    }
}
﻿//LEFT OFF ON SCRIPT TO VERIFY CODE OU HAVE TO CHANGE THE EMAIL EACH TRY TO RESET IT
//YOU LEARNED TO RESET BROWSER COOKIES ,SEND KEYS TO COMPONET BY FOCUS AND TO LOOP THROUGH ON LOADING A BROWSER WINDOW
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApplication4
{
    internal class Twitter {
        public static WebBrowser webBrowser4= null;

        public static  WebBrowser webBrowser3 = null;
         int firstclickbyattribute =0;
        int i = 0;//used as a counter in the signupby email linkcliker
        public Twitter(WebBrowser webBrowser2)
        { webBrowser3 = webBrowser2;
            //used to clear rowser when a wrong input is entered and to rest it from new condition
            System.Diagnostics.Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 2");//has to be used inside where a browser isisntianed


            webBrowser3.DocumentCompleted += webBrowser3_DocumentCompleted;//this has to be decleredin the sam merhod as itweb3 is isnatained
            // System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss" + webBrowser3.Document.Title);
             System.Diagnostics.Debug.WriteLine("inside twitter222" );

        }

        public  Twitter() { }



   // { //SqlCeConnection thisConnection

       public void twitter1()
    {
            // Form1.textBox1.Text = "Picture to post";

            System.Diagnostics.Debug.WriteLine("insied  Yelper class way to  go little buddy2");
             webBrowser3.Navigate("https://twitter.com/?lang=en");

            // webBrowser3.Navigate("https://twitter.com/?lang=en");
            System.Diagnostics.Debug.WriteLine("insiedaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  Yelper class way to  go little buddy2");



        }
        //used for signing up with twitter
        private void webBrowser3_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        { if (firstclickbyattribute < 1)
            {
                System.Diagnostics.Debug.WriteLine("insied  twitter line 47");
                //used to demarkk older browser error
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                firstclickbyattribute = 1;

                SendKeys.Send("{ENTER}");

                return;




                //  clickThroughByTags(1);//GOES TO THE SIGN UP LINK
                // twittersignupcliker(webBrowser3);
                // webBrowser3.DocumentCompleted += webBrowser3_DocumentCompleted;
                // clickThroughByTags(9);//GOESTO VERIFY BY EMAIL
            }

            ////

            if (firstclickbyattribute == 1)

            {
                //  sets focus on signupby email option
                webBrowser3.Focus();
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                SendKeys.Send("{TAB}");
                firstclickbyattribute = 2;
                SendKeys.Send("{ENTER}");

                // Console.ReadKey();//pause program
                return;
            }
            ////////
            if (firstclickbyattribute == 2)//used to set foxcus on the name input
            {
                System.Diagnostics.Debug.WriteLine("NOT HERE");

                string p = "ace";
                //webBrowser4.Focus();
                SendKeys.Send("{TAB}" + "{TAB}" + "{TAB}");//used to set foxcus on the name input
                SendKeys.Send(p);//sends name
                SendKeys.Send("{TAB}");//moves focouse to email
                SendKeys.Send("GVVot1122@yahoo.com");//sends email
                firstclickbyattribute = 3;
                SendKeys.Send("{ENTER}" + "{TAB}");//clcike enter
                return;

            }
            ////////
            if (firstclickbyattribute == 3)//used to set foxcus on the PHONE input
            {
                SendKeys.Send("{TAB}" + "{TAB}" + "{TAB}");//used to set foxcus on the number input

                firstclickbyattribute = 4;
                SendKeys.Send("4407772292");//sETS PHONE FEILD
                SendKeys.Send("{TAB}" + "{TAB}"  );//used to CLICK ENTER the number input
                SendKeys.Send("{ENTER}" );//used to CLICK ENTER

                return;

            }
                 if (firstclickbyattribute == 4)//used to set THE SENT VEIFIRCATION CODE
            {
                SendKeys.Send("{TAB}" + "{TAB}");//used to set foxcus on the VERI number input

                SendKeys.Send("VERIFIED");//sends VERI NUMBER
              
                firstclickbyattribute = 5;
               // SendKeys.Send("{ENTER}");//used to ENTER CLICK

                return;
                }
            //      if (firstclickbyattribute == 3)//used to set foxcus on the name input
            //      {
            //   firstclickbyattribute = 4;
            //   return;
            //     }
            /////


            ///////


            ///  if (firstclickbyattribute == 1) { clickThroughByTags(11);
            //     firstclickbyattribute = 2;
            // }
        }
        //
       






         //THIS IS NOT USED BUT A REFRENCE FOR ELEMENTS
        public void clickThroughByTags2(int s)
        {
            int firstclickbyattribute2 = 0;
            System.Diagnostics.Debug.WriteLine("insied  twitter line70");

            /////////
            // System.Diagnostics.Debug.WriteLine("u made it here hehehaaaaaaaaaeh");
            //  System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss" + webBrowser3.Document.Title);
            HtmlElementCollection links2 = webBrowser4.Document.GetElementsByTagName("a");
            // string e = links1.ToString();
            //System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss"+e);

            // HtmlElementCollection lnks1 = webBrowser1.Focus(d);
            /////////////
            ////////////
            foreach (HtmlElement link in links2)
            {

                System.Diagnostics.Debug.WriteLine("inside signupthruelements" + link.ToString());//99
                if (firstclickbyattribute2 <= s)
                {
                    link.GetAttribute("href");//99

                    link.InvokeMember("Click");//99
                    System.Diagnostics.Debug.WriteLine("looking for a link in twitter" + link);//99 if only 99 line where in this it would perpetualy open links
                    firstclickbyattribute2++;

                }

            } //try a switch case style whne efactoring


        }

        //
        public void clickThroughByTags(int s)
        {
            int firstclickbyattribute2 = 0;
            System.Diagnostics.Debug.WriteLine("insied  twitter line70");

            /////////
            // System.Diagnostics.Debug.WriteLine("u made it here hehehaaaaaaaaaeh");
            //  System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss" + webBrowser3.Document.Title);
            HtmlElementCollection links1 =  webBrowser3.Document.GetElementsByTagName("a");
           // string e = links1.ToString();
            //System.Diagnostics.Debug.WriteLine("llliiiiiiiiiiiinnnnnnnnkkkkkkkkkkksssssss"+e);

            // HtmlElementCollection lnks1 = webBrowser1.Focus(d);
            /////////////
            ////////////
            foreach (HtmlElement link in links1)
            {
                
                System.Diagnostics.Debug.WriteLine("CLICKTHRUBY TAGS L 73" + link.ToString());//99
                if (firstclickbyattribute2 <= s)
                {
                    link.GetAttribute("href");//99

                    link.InvokeMember("Click");//99
                    System.Diagnostics.Debug.WriteLine("looking for a link in twitter" + link);//99 if only 99 line where in this it would perpetualy open links
                    firstclickbyattribute2++;

                }

            } //try a switch case style whne efactoring


        }
          

    }
}














﻿namespace WindowsFormsApplication4
{
    internal class CreatNewAccountListing1
    {
        public CreatNewAccountListing1()
        {

            System.Diagnostics.Debug.WriteLine("Send to debugxxxxxxxxxxxxxxxxxxxxxxxx output.");
        }

        public CreatNewAccountListing1(string u, string um)
        {       //ffrom form1 user
            string useorwebsite = u;
             System.Diagnostics.Debug.WriteLine("user/websites." + useorwebsite);
            //ffrom form1 user name of media site
            string useorwebsitepassword = um;
            System.Diagnostics.Debug.WriteLine("websites password same for all accounts." + useorwebsitepassword);
            //ffrom form1 mediasite name of media site
           // string mediasitename4 = ms1;
            //System.Diagnostics.Debug.WriteLine(" mediasitename is ayhoooo " + mediasitename4);





        }
    }
}
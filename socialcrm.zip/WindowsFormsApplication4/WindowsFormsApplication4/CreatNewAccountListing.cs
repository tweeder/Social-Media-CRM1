﻿namespace WindowsFormsApplication4
{
    internal class CreatNewAccountListing1
    {
        public CreatNewAccountListing1()
        {

            System.Diagnostics.Debug.WriteLine("Send to debugxxxxxxxxxxxxxxxxxxxxxxxx output." );
        }
    }
}
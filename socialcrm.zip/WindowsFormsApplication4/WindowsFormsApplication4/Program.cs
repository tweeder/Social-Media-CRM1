﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsApplication4
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// all functionalityis handled by fomr events
        /// </summary>
        [STAThread]
        static void Main()
        { 
        Debug.WriteLine("Send to debug outrrrrrrrrput.");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            Debug.WriteLine("Send to debugffffffffffffffffffffffffff output.");


        }
    }
}

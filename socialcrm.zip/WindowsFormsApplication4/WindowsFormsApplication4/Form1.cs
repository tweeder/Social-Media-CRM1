﻿// you left off needing to implementa full site sign up algro yelp or face.once signup is succesfulu verify by makeing a simple post


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        int firstclickbyattribute = 0;
        public int value;
          private CreatNewAccountListing1[] customers;
        private int couterforarrayoflistngs = 0;
        private string userselected1;
        private string password1;
        private string mediasitename1;
        private int firstclickbyattributeround = 0;
        // used for the add new customer input box
        string newcustomerinput = "";
        //used for themail variable
       string  emailinput ="";

        public void createNewListingArray()
        {   //counter to make sure you dont reintialize the array eventually will get this from a file
            if (couterforarrayoflistngs == 0)
            //array of users/websites from form1
            {
                customers = new CreatNewAccountListing1[5];// 
            }
            else { }
        }

        public void createNewListing1()
        {// populateing an array up to 5
         // customers[0] = new CreatNewAccountListing1(user11, password33, mediasiteame33);
         //   customers[1] = new CreatNewAccountListing1(getuserforprogram(), getPassword(), gettMediasiteName());
       
            //GETS A  SELECTED  CLIENT
            string user11 =          getuserforprogram();
            //SETS THE PASWORD FOR THE CLIENT
            string password33 =     getPassword();
            //GETS THE MEDIA SITES TO REGISTER not used neither is media site variable
            string mediasiteame33 = gettMediasiteName();
            //   button1.Text = "howdy biddy thanks for feeling on me";
            //ADDS THE CLIENT TO THE ARRAY
            customers[couterforarrayoflistngs] = new CreatNewAccountListing1(user11, password33);
            couterforarrayoflistngs++;//changes the number of clients in the database






        }

        public object ListBox1 { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }
        // CREATE NEW ACCOUNT
        private void button1_Click(object sender, EventArgs e)
        {           //INTIALIZES THE CLIENT ARRAY IF IT HASNT BEEN
            createNewListingArray();
            // CREATS A NEW CLIENT LISTING IN THE ARRAY
            createNewListing1();
            //1string user =          getuserforprogram();
            //1string password3 =     getPassword();
            //1 string mediasiteame3 = gettMediasiteName();
            //   button1.Text = "howdy biddy thanks for feeling on me";


            // This will add a new customer/user
            //1 FormVallidaorforForm1 fvff1 = new FormVallidaorforForm1();
            // 1 CreatNewAccountListing1 obj = new CreatNewAccountListing1(user,password3,mediasiteame3 );
            //  t(richTextBox2.Text);

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {  
           // string m = textBox1.Text ;
           // button1.Text = m;

         }
        //is used to select the user in the  listBox1 and set user11 field
        public void setuserforprogram(string w)
        {  userselected1 = w; }
        //is used to select the user in the  listBox1 and set user11 field

        public string  getuserforprogram()
        {
            string userselected2 = userselected1;
            System.Diagnostics.Debug.WriteLine("userselected2." + userselected2 );

            return userselected2;
        }
        // end of settig main user to pass to creatnew accouts class
                //SETS THES USER FIELD FROM THE SELECTED BOX
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {       /// GETS THE CURRENT SELECTED CLIENT
            string s = listBox1.GetItemText(listBox1.SelectedItem);
            textBox3.Text = s;
            //SETS THES USER FIELD FROM THE SELECTED BOX
            setuserforprogram(s);
           // System.Diagnostics.Debug.WriteLine("hiiiiiiiiiii." + s + "only u");
        }
 
        // start of settig main password to pass to creat new accouts class
        public void setPassword(string sp)
        { password1 = sp; }
        //takes the pass word fromclistBox2 set field listBox2
        public string getPassword()
        {
            string password2 = password1;
            System.Diagnostics.Debug.WriteLine("password2." + password2);

            return password2;
        }        // end of settig mainpASSWORD pass to creatnew accouts class

        // mediasiteame33 set this field by clicking buttfour and gest data from checkkboxlist_1
        public void setMediasiteName(string msn)
        { mediasitename1 = msn; }
        public string gettMediasiteName()
        {
            string mediasitename2 = mediasitename1;
            System.Diagnostics.Debug.WriteLine("mediasitename2." + mediasitename2);

            return mediasitename2;
        }
        // end of settig mediasitename pass to creatnew accouts class
        ////////

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string usernameonmediasite = textBox4newuser.GetItemText(textBox4newuser.SelectedItem);
           // setMediasiteName(usernameonmediasite);

        }

         

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }
        //thisn but 5 update account button

        private void button5_Click(object sender, EventArgs e)
        {
            this.webBrowser1.Navigate("https://twitter.com/?lang=en");
           }

        private void label8_Click(object sender, EventArgs e)
        {

        }



        /// //////////////////////




        void webBrowser2_DocumentCompleted( )
        {      if (firstclickbyattributeround < 1)
            {
                MessageBox.Show("Completed Now2!");
                firstclickbyattributeround++;
                ///////////

                  System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
                 System.Diagnostics.Debug.WriteLine("waiting on a timer1");

                  t.Interval = 150000; // specify interval time as you want
                  EventHandler timer_Tick = null;
                  t.Tick += new EventHandler(timer_Tick);
                  t.Start();
                  System.Diagnostics.Debug.WriteLine("waiting on a timrrrrrrrrrrrrrrrrrrer");


                //////////////////



                clickThroughByTags(3);
            }
           // clickThroughByTags(3);

            //   this.webBrowser1.Document.GetElementById("oauth_signup_client_fullname").SetAttribute("value", "example@example.com");
            //      this.webBrowser1.Document.GetElementById( "oauth_signup_client_phone_number").SetAttribute("value", "example@example.com");
            //

            // clickThroughByElmentId();

        }
        void webBrowser3_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            MessageBox.Show("Completed Now3!");


            //   this.webBrowser1.Document.GetElementById("oauth_signup_client_fullname").SetAttribute("value", "example@example.com");
            //      this.webBrowser1.Document.GetElementById( "oauth_signup_client_phone_number").SetAttribute("value", "example@example.com");
            //

            // clickThroughByElmentId();

        }


        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {   // HtmlElement link = this.webBrowser1.Document.GetElementsByTagName(" a");
            //   link.InvokeMember("Click");
            // this.webBrowser1.Document.GetElementById("session[username_or_email]").SetAttribute("value", "example@example.com");
            // this.webBrowser1.Document.GetElementById("session[password]").SetAttribute("value", "example@example.com");
            // 9 //   clickThroughByTags(2);
            //  Thread.Sleep(10000);
            //9 webBrowser2_DocumentCompleted();
          //  Yelper() yelper2 = new yelper1;
           // yelper2.yelper1();
          //  if (firstclickbyattributeround < 2)
             //   webBrowser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowser2_DocumentCompleted);

           // else if (firstclickbyattributeround < 3)
               // webBrowser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowser3_DocumentCompleted);


            // System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
            //System.Diagnostics.Debug.WriteLine("waiting on a timer1");

            // t.Interval = 15000; // specify interval time as you want
            // EventHandler timer_Tick = null;
            // t.Tick += new EventHandler(timer_Tick);
            // t.Start();
            // System.Diagnostics.Debug.WriteLine("waiting on a timer");

            // this.webBrowser1.Document.GetElementById("session[username_or_email]").SetAttribute("value", "example@example.com");
            //  this.webBrowser1.Document.GetElementById("session[password]").SetAttribute("value", "example@example.com");
            // clickThroughByTags(4);//to pick sign up by email

            // clickThroughByElmentId();
        }
        private void clickThroughByElmentId()
        {
            //  System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();


            //  t.Interval = 15000; // specify interval time as you want
            ////  EventHandler timer_Tick = null;
            //  t.Tick += new EventHandler(timer_Tick);
            //  t.Start();

            MessageBox.Show("Completed Now for email and user info!");
            this.webBrowser1.Document.GetElementById("oauth_signup_client_fullname").SetAttribute("value", "example@example.com");
          this.webBrowser1.Document.GetElementById( "oauth_signup_client_phone_number").SetAttribute("value", "example@example.com");
//////////////
        }
        private  void clickThroughByTags(int s) {
            /////////
            System.Diagnostics.Debug.WriteLine("u made it here heheheh");

            HtmlElementCollection links = webBrowser1.Document.GetElementsByTagName("a");
            // HtmlElementCollection lnks1 = webBrowser1.Focus(d);
            /////////////
            ////////////
            foreach (HtmlElement link in links)
            {
                System.Diagnostics.Debug.WriteLine("linklinklink" + link.ToString());//99
                if (firstclickbyattribute <= s)
                {
                    link.GetAttribute("href");//99

                    link.InvokeMember("Click");//99
                    System.Diagnostics.Debug.WriteLine("linklddddddddinklink" + link);//99 if only 99 line where in this it would perpetualy open links
                    firstclickbyattribute++;
                 
                }

            } //try a switch case style whne efactoring
           

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        /// passes the check boxed media sites to a validator and submission process
        private void button4_Click(object sender, EventArgs e)
        {           
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                if (checkedListBox1.GetItemChecked(i))
                {// Do selected stFF
                    System.Diagnostics.Debug.WriteLine("ZZZZZZZZZZZZZZ" + i + "ZZZZZZZZZZ" + checkedListBox1.GetItemChecked(i));//99 if only 99 line where in this it would perpetualy open links
                                                                                                                                //this.value = checkedListBox1.GetItemText(checkedListBox1.SelectedItem);
                                                                                                                                // System.Diagnostics.Debug.WriteLine("mediasitetoadd." + this.value);
                                                                                                                                //string value = checkedListBox1.Items[i].ToString();
                                                                                                                                // System.Diagnostics.Debug.WriteLine("mediasitetoadd2." + this.value);
                    value = i;
                    // used to get data from form one and create a new social media listing
                    FormVallidaorforForm1 fvffone = new FormVallidaorforForm1(value, webBrowser1);
                    //// check to see if object key field use name is in a nnnewaccountlisting array


                }


                else { }
            // Do unselected stuff


            // used to get data from form one and create a new social media listing
           // FormVallidaorforForm1 fvffone = new FormVallidaorforForm1(value,webBrowser1);
            //// check to see if object key field use name is in a nnnewaccountlisting array

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {/////

                    /////
                  
            //string usernameonmediasite = listBox4.GetItemText(listBox4.SelectedItem);


        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        /// changes the password for all the sites
        private void buttonpasswordchange_Click(object sender, EventArgs e)
        {      // gets the text from the pass wordbox
            string pswd = PASSWORDBox4.Text;
            setPassword(pswd);

            System.Diagnostics.Debug.WriteLine("ZZZZZZZZZZZZZZ" + pswd + "ZZZZZZZZZZ"  );//99 if only 99 line where in this it would perpetualy open links

        }

        private void PASSWORDBox4_TextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void btnewaaacount_Click(object sender, EventArgs e)
        {         //takes the tped input  an adds it to a new account
            listBox1.Items.Add("Your item"+newcustomerinput);
           // newcustomerinput = "";
            //clears the tex in the imput box
            textBox4newuser.Clear();

        }

        private void textBox4newuser_TextChanged(object sender, EventArgs e)
        {
            newcustomerinput = "";
            newcustomerinput = textBox4newuser.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            emailinput = textBox4.Text;
            emailboz.Text = emailinput;
            emailboz.Clear();

        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void emailboz_TextChanged(object sender, EventArgs e)
        {           //get the entered email text
           
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
